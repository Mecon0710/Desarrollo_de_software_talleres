
import { Course } from './course.js';

import { dataCourses } from './dataCourses.js';

import { Student } from './students.js';

import { dataStudents } from './dataStudents.js';

let coursesTbody: HTMLElement = document.getElementById('courses')!;
const studentsTbody: HTMLElement = document.getElementById('students')!;
const btnfilterByCredits:  HTMLElement = document.getElementById("button-creditsByName")!;
const btnfilterByName: HTMLElement = document.getElementById("button-filterByName")!;
const inputSearchBox: HTMLInputElement = <HTMLInputElement> document.getElementById("search-box")!;
const inputSearchMIN: HTMLInputElement = <HTMLInputElement> document.getElementById("search-MIN")!;
const inputSearchMAX: HTMLInputElement = <HTMLInputElement> document.getElementById("search-MAX")!;
const totalCreditElm: HTMLElement = document.getElementById("total-credits")!;

btnfilterByName.onclick = () => applyFilterByName();
btnfilterByCredits.onclick = () => applyFilterByCredits();

renderCoursesInTable(dataCourses);
renderStudentsInTable(dataStudents);

totalCreditElm.innerHTML = `${getTotalCredits(dataCourses)}`


function renderCoursesInTable(courses: Course[]): void {
  console.log('Desplegando cursos');
  courses.forEach((course) => {
    let trElement = document.createElement("tr");
    trElement.innerHTML = `<td>${course.name}</td> 
                           <td>${course.professor}</td>
                           <td>${course.credits}</td>`;
    coursesTbody.appendChild(trElement);
  });
}

function renderStudentsInTable(students: Student[]): void {
  console.log('Desplegando información estudiantes');
  students.forEach((student) => {
  let trElement = document.createElement("tr");
  let trElement2 = document.createElement("tr");
  let trElement3 = document.createElement("tr");
  let trElement4 = document.createElement("tr");
  let trElement5 = document.createElement("tr");
  trElement.innerHTML =`<th>Código</th><td>  ${student.codigo}</td>`;
  trElement2.innerHTML =`<th>Cédula</th><td> ${student.cedula}</td>`;
  trElement3.innerHTML =`<th>Edad</th><td>  ${student.edad}</td>`;
  trElement4.innerHTML =`<th>Dirección</th><td> ${student.direccion}</td>`;
  trElement5.innerHTML =`<th>Teléfono</th><td> ${student.telefono}</td>`;
  studentsTbody.appendChild(trElement)
  studentsTbody.appendChild(trElement2)
  studentsTbody.appendChild(trElement3)
  studentsTbody.appendChild(trElement4)
  studentsTbody.appendChild(trElement5)
  });
}

function applyFilterByName() { 
  let text = inputSearchBox.value;
  text = (text == null) ? '' : text;
  clearCoursesInTable();
  let coursesFiltered: Course[] = searchCourseByName(text, dataCourses);
  renderCoursesInTable(coursesFiltered);
}

function applyFilterByCredits() { 
  let MAX = parseInt(inputSearchMAX.value);
  let MIN = parseInt( inputSearchMIN.value);
  MAX = (MAX == null) ? -1 : MAX;
  MIN = (MIN == null) ? -1 : MIN;
  clearCoursesInTable();
  let coursesFiltered: Course[] = searchCourseByCredits(MAX, MIN,dataCourses);
  renderCoursesInTable(coursesFiltered);
}

function searchCourseByCredits(MAX:number, MIN: number, courses: Course[]) {
  return (MAX=== -1 && MIN=== -1 )? dataCourses : courses.filter( c => 
    c.credits >= MIN && c.credits <= MAX );
}

function searchCourseByName(nameKey: string, courses: Course[]) {
  return nameKey === '' ? dataCourses : courses.filter( c => 
    c.name.match(nameKey));
}

function getTotalCredits(courses: Course[]): number {
  let totalCredits: number = 0;
  courses.forEach((course) => totalCredits = totalCredits + course.credits);
  return totalCredits;
}

function clearCoursesInTable() {
  while (coursesTbody.hasChildNodes()) {
    if (coursesTbody.firstChild != null) {
      coursesTbody.removeChild(coursesTbody.firstChild);
     
    }
  }
}