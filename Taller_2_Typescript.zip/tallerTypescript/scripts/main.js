import { dataCourses } from './dataCourses.js';
import { dataStudents } from './dataStudents.js';
var coursesTbody = document.getElementById('courses');
var studentsTbody = document.getElementById('students');
var btnfilterByCredits = document.getElementById("button-creditsByName");
var btnfilterByName = document.getElementById("button-filterByName");
var inputSearchBox = document.getElementById("search-box");
var inputSearchMIN = document.getElementById("search-MIN");
var inputSearchMAX = document.getElementById("search-MAX");
var totalCreditElm = document.getElementById("total-credits");
btnfilterByName.onclick = function () { return applyFilterByName(); };
btnfilterByCredits.onclick = function () { return applyFilterByCredits(); };
renderCoursesInTable(dataCourses);
renderStudentsInTable(dataStudents);
totalCreditElm.innerHTML = "" + getTotalCredits(dataCourses);
function renderCoursesInTable(courses) {
    console.log('Desplegando cursos');
    courses.forEach(function (course) {
        var trElement = document.createElement("tr");
        trElement.innerHTML = "<td>" + course.name + "</td> \n                           <td>" + course.professor + "</td>\n                           <td>" + course.credits + "</td>";
        coursesTbody.appendChild(trElement);
    });
}
function renderStudentsInTable(students) {
    console.log('Desplegando información estudiantes');
    students.forEach(function (student) {
        var trElement = document.createElement("tr");
        var trElement2 = document.createElement("tr");
        var trElement3 = document.createElement("tr");
        var trElement4 = document.createElement("tr");
        var trElement5 = document.createElement("tr");
        trElement.innerHTML = "<th>C\u00F3digo</th><td>  " + student.codigo + "</td>";
        trElement2.innerHTML = "<th>C\u00E9dula</th><td> " + student.cedula + "</td>";
        trElement3.innerHTML = "<th>Edad</th><td>  " + student.edad + "</td>";
        trElement4.innerHTML = "<th>Direcci\u00F3n</th><td> " + student.direccion + "</td>";
        trElement5.innerHTML = "<th>Tel\u00E9fono</th><td> " + student.telefono + "</td>";
        studentsTbody.appendChild(trElement);
        studentsTbody.appendChild(trElement2);
        studentsTbody.appendChild(trElement3);
        studentsTbody.appendChild(trElement4);
        studentsTbody.appendChild(trElement5);
    });
}
function applyFilterByName() {
    var text = inputSearchBox.value;
    text = (text == null) ? '' : text;
    clearCoursesInTable();
    var coursesFiltered = searchCourseByName(text, dataCourses);
    renderCoursesInTable(coursesFiltered);
}
function applyFilterByCredits() {
    var MAX = parseInt(inputSearchMAX.value);
    var MIN = parseInt(inputSearchMIN.value);
    MAX = (MAX == null) ? -1 : MAX;
    MIN = (MIN == null) ? -1 : MIN;
    clearCoursesInTable();
    var coursesFiltered = searchCourseByCredits(MAX, MIN, dataCourses);
    renderCoursesInTable(coursesFiltered);
}
function searchCourseByCredits(MAX, MIN, courses) {
    return (MAX === -1 && MIN === -1) ? dataCourses : courses.filter(function (c) {
        return c.credits >= MIN && c.credits <= MAX;
    });
}
function searchCourseByName(nameKey, courses) {
    return nameKey === '' ? dataCourses : courses.filter(function (c) {
        return c.name.match(nameKey);
    });
}
function getTotalCredits(courses) {
    var totalCredits = 0;
    courses.forEach(function (course) { return totalCredits = totalCredits + course.credits; });
    return totalCredits;
}
function clearCoursesInTable() {
    while (coursesTbody.hasChildNodes()) {
        if (coursesTbody.firstChild != null) {
            coursesTbody.removeChild(coursesTbody.firstChild);
        }
    }
}
