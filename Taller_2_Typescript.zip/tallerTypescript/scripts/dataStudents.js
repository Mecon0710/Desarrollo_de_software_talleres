import { Student } from './students.js';
export var dataStudents = [
    new Student(202011876, 1000714231, "19 años", "Cr 82 #17 - 95", 3226146)
];
