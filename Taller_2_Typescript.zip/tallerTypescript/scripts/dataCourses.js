import { Course } from './course.js';
export var dataCourses = [
    new Course("Desarrollo SW", "Rubby Casallas", 3),
    new Course("Natación", "Henry Parrado", 1),
    new Course("Sistemas transaccionales", "Claudia Jimenez", 3),
    new Course("Biología", "Jesus Uribe", 3),
    new Course("Sóftbol", "Jose Aguirre de la Espriella", 1)
];
